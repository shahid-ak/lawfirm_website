from django.apps import AppConfig


class LawmasterConfig(AppConfig):
    name = 'lawmaster'
