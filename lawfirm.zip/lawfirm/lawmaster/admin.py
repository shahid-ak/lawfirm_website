from django.contrib import admin
from .models import Field, Lawyers

# Register your models here.

admin.site.register(Field)
admin.site.register(Lawyers)